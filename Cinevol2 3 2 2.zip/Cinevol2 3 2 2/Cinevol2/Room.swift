//
//  Room.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 22/05/23.
//

import Foundation

struct Room {
    
    let roomId: Int
    let seats: Int
}

let rooms : [Room] = [

    Room(roomId: 1, seats: 16),
    
    Room(roomId: 2, seats: 15),
    
    Room(roomId: 3, seats: 21),
    
    Room(roomId: 4, seats: 14),
]
