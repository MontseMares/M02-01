//
//  Seat.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 22/05/23.
//

import Foundation

enum SeatStatus
{
    case ocuppied
    case empty
    case reserved
}

struct Seat
{
    let seatId: Int
    var status: SeatStatus
}
