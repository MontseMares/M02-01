//
//  Movie.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 09/05/23.
//

import Foundation
import UIKit

struct Movie {
    let id: Int
    let images: [UIImage]
    let title: String
    let description: String
    let genre: String
    let timeDurection: Double
}

let movies: [Movie] = [
    
    Movie(id:1, images: [UIImage(named: "eo")!, UIImage(named: "eo-small")!],title: "EO", description: "El legendario director Jerzy Skolimowski dirige una de sus películas más libres y visualmente inventivas, siguiendo el viaje de un burro gris llamado Eo. Tras ser expulsado del circo ambulante, Eo emprende una travesía por la campiña polaca e italiana, experimentando crueldad y bondad a partes iguales. Inspirada libremente en Al azar, Baltasar (1966), de Robert Bresson, EO sitúa al espectador en la perspectiva de su protagonista cuadrúpedo mientras es testigo de los excesos y males de la sociedad europea actual.", genre: "Drama", timeDurection:  82.0),
    
    Movie(id:2, images: [UIImage(named: "trigal")!, UIImage(named: "trigal-small")!],title: "Trigal", description: "Sofía es una niña de trece años que va de vacaciones a la casa de campo de su prima Cristina en Sonora. Durante estos días de juegos y descubrimientos las dos se verán sumergidas en un triángulo amoroso con un hombre casi veinte años mayor que ellas, lo que marcará su paso de la pubertad a la adolescencia. La ópera prima de Anabel Caso es un coming-of-age costumbrista basado en los recuerdos de su juventud que explora el deseo y la sexualidad femeninos de una forma tan sugestiva como dolorosa", genre: "Drama | Adolescencia", timeDurection:  115.0),
    
    Movie(id:3, images: [UIImage(named: "claraSola")!, UIImage(named: "claraSola-small")!],title: "Clara Sola", description: "En un pueblo remoto de Costa Rica, Clara, una retraída mujer de 40 años de edad, es considerada una curandera por los pobladores. Su madre, Doña Fresia, la ha controlado durante años y se encarga de que sólo se dedique a sus labores de “santidad”. Un día, sin embargo, al conocer a un joven agricultor, Clara comenzará a experimentar un despertar sexual y místico que podría ayudarla curarse a sí misma. Con toques de realismo mágico y una propuesta narrativa donde tanto la corporeidad de la protagonista como la naturaleza de su entorno conforman el centro gravitacional, la ópera prima de la joven directora Nathalie Álvarez Mesén es una poética inmersión al universo de la sexualidad femenina.",genre: "Drama | Religión. Realismo mágico", timeDurection:  106.0),
    Movie(id:4, images: [UIImage(named: "cenote")!, UIImage(named: "cenote-small")!],title: "Cenote", description: "En el norte de Yucatán, los pozos naturales llamados cenotes constituían la única fuente de agua para los mayas. Algunos se usaban para sacrificios rituales y los mayas creían que estas fuentes sagradas conectaban al mundo con la vida después de la muerte. La cineasta japonesa Kaori Oda realizó varios viajes a Yucatán para filmar las profundidades turquesas de los pozos y conocer a los locales. El resultado es una meditación poética y una experiencia sensorial sobre el papel mítico de estos cuerpos de agua en la vida maya.",  genre: "Documental | Naturaleza", timeDurection:  75.0),
    
    Movie(id:5, images: [UIImage(named: "volvere")!, UIImage(named: "volvere-small")!],title: "Volveré", description: "En un país con miles de desaparecidos, Alejandra, una mujer frívola, divorciada y madre de dos hijos, se enfrenta a la desaparición de su hermano Salvador, quien documenta la depredación ecológica de una minera canadiense. La vida se vuelve más difícil con pérdidas laborales y familiares. Alejandra luchará por proteger a su familia y aprenderá que el amor lo enfrenta todo.",genre: "Ficción", timeDurection:  102.0),
    Movie(id:6, images: [UIImage(named: "home")!, UIImage(named: "home-small")!],title: "Home is Somewhere Else", description: "Jasmine, una niña estadounidense de 11 años, vive con miedo de que sus padres indocumentados sean deportados; las hermanas Evelyn y Elizabeth se encuentran alejadas por sus diferentes estatus migratorios; y Lalo, quien creció en Utah y fue deportado a México a los 23 años, se ha convertido en activista binacional. La más reciente película del documetalista Carlos Hagerman, en conjunto con el animador Jorge Villalobos, es una emotiva reflexión sobre el fenómeno migratorio entre México y Estados Unidos, contado a través de relatos completamente animados.",genre: "Documental. Animación | Inmigración. Animación para adultos", timeDurection:  87.0),
    
    Movie(id:7, images: [UIImage(named: "volverte")!, UIImage(named: "volverte-small")!],title: "Volverte a ver", description: "Lina, Angy y Edith, familiares de personas desaparecidas, se entrenan como peritos forenses para poder participar en la exhumación de más de 200 cuerpos que la fiscalía morelense enterró en secreto. El documental acompaña a las mujeres en su adiestramiento en labores forenses y durante su participación en el desenterramiento de los cuerpos. Sus análisis nos revelan una realidad escalofriante: el Estado es parte de la cadena de desaparición de personas a través de sus fosas ocultas.",genre: "Documental", timeDurection:  103.0)
    
]

let popularMovies: [Movie] = [
    
    Movie(id:7, images: [UIImage(named: "volverte")!, UIImage(named: "volverte-small")!],title: "Volverte a ver", description: "Lina, Angy y Edith, familiares de personas desaparecidas, se entrenan como peritos forenses para poder participar en la exhumación de más de 200 cuerpos que la fiscalía morelense enterró en secreto. El documental acompaña a las mujeres en su adiestramiento en labores forenses y durante su participación en el desenterramiento de los cuerpos. Sus análisis nos revelan una realidad escalofriante: el Estado es parte de la cadena de desaparición de personas a través de sus fosas ocultas.",genre: "Documental", timeDurection:  103.0),
    Movie(id:6, images: [UIImage(named: "home")!, UIImage(named: "home-small")!],title: "Home is Somewhere Else", description: "Jasmine, una niña estadounidense de 11 años, vive con miedo de que sus padres indocumentados sean deportados; las hermanas Evelyn y Elizabeth se encuentran alejadas por sus diferentes estatus migratorios; y Lalo, quien creció en Utah y fue deportado a México a los 23 años, se ha convertido en activista binacional. La más reciente película del documetalista Carlos Hagerman, en conjunto con el animador Jorge Villalobos, es una emotiva reflexión sobre el fenómeno migratorio entre México y Estados Unidos, contado a través de relatos completamente animados.",genre: "Documental. Animación | Inmigración. Animación para adultos", timeDurection:  87.0),
    Movie(id:4, images: [UIImage(named: "cenote")!, UIImage(named: "cenote-small")!],title: "Cenote", description: "En el norte de Yucatán, los pozos naturales llamados cenotes constituían la única fuente de agua para los mayas. Algunos se usaban para sacrificios rituales y los mayas creían que estas fuentes sagradas conectaban al mundo con la vida después de la muerte. La cineasta japonesa Kaori Oda realizó varios viajes a Yucatán para filmar las profundidades turquesas de los pozos y conocer a los locales. El resultado es una meditación poética y una experiencia sensorial sobre el papel mítico de estos cuerpos de agua en la vida maya.",genre: "Documental | Naturaleza", timeDurection:  75.0),
    
]

