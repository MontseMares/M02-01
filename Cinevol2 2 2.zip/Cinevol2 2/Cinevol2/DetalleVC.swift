//
//  DetalleVC.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 12/05/23.
//

import UIKit

class DetalleVC: UIViewController {

    var pelicula: Pelicula?
    
    @IBOutlet weak var textTitle: UILabel!
    
    @IBOutlet weak var imagenPelicula: UIImageView!
    
    @IBOutlet weak var textDesc: UILabel!
    
    @IBOutlet weak var textGenero: UILabel!
    
    @IBOutlet weak var textDuracion: UILabel!
    
    @IBOutlet weak var segementedControlOutlet: UISegmentedControl!
    
    @IBAction func segmentControlAction(_ sender: UISegmentedControl) {
        switch segementedControlOutlet.selectedSegmentIndex {
            
        case 0:
            textTitle.text = pelicula?.titulo
            textGenero.text = pelicula?.genero
            textDesc.text = pelicula?.desc
            if let duracion = pelicula?.duracionTiempo {
                            textDuracion.text = "\(duracion) minutos"
                        } else {
                            textDuracion.text = "Duración no disponible"
                        }
            break
        case 1:
            textTitle.text = "Horario"
            textGenero.text = ""
            textDesc.text = ""
            textDuracion.text = ""
            break
        default:
            break
        }
            
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagenPelicula.image = pelicula?.image
        segmentControlAction(segementedControlOutlet)
        
    }
}
