//
//  Movie.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 09/05/23.
//

import Foundation
import UIKit


struct Pelicula {
    
    var titulo: String
    var genero: String
    var image: UIImage
    var desc: String
    var duracionTiempo: Double
    
}

struct Actor {
    var nombre: String
}

struct Sala{
    var numeroSala: Int
    var asiento: Int
}

struct Cine{
    var nombreCine: String
    var ubucacion: String
    var numSalas: [Sala]
}

struct Funcion {
    var pelicula: Pelicula
    var sala: Sala
    var inicio: Double
    var fin: Double
    var asientoDisp: Int
}

struct Funciones {
    
    var funciones: [Funcion]
    var dia: Date
    
}


let peliculas: [Pelicula] = [
    Pelicula(titulo: "EO", genero: "Drama", image: UIImage(named: "eo")!,desc: "El legendario director Jerzy Skolimowski dirige una de sus películas más libres y visualmente inventivas, siguiendo el viaje de un burro gris llamado Eo. Tras ser expulsado del circo ambulante, Eo emprende una travesía por la campiña polaca e italiana, experimentando crueldad y bondad a partes iguales. Inspirada libremente en Al azar, Baltasar (1966), de Robert Bresson, EO sitúa al espectador en la perspectiva de su protagonista cuadrúpedo mientras es testigo de los excesos y males de la sociedad europea actual.", duracionTiempo: 82.0),
    Pelicula(titulo: "Trigal", genero: "Drama | Adolescencia", image: UIImage(named: "trigal")!,desc: "Sofía es una niña de trece años que va de vacaciones a la casa de campo de su prima Cristina en Sonora. Durante estos días de juegos y descubrimientos las dos se verán sumergidas en un triángulo amoroso con un hombre casi veinte años mayor que ellas, lo que marcará su paso de la pubertad a la adolescencia. La ópera prima de Anabel Caso es un coming-of-age costumbrista basado en los recuerdos de su juventud que explora el deseo y la sexualidad femeninos de una forma tan sugestiva como dolorosa", duracionTiempo: 115.0),
    Pelicula(titulo: "Clara Sola", genero: "Drama | Religión. Realismo mágico", image: UIImage(named: "claraSola")!,desc:  "En un pueblo remoto de Costa Rica, Clara, una retraída mujer de 40 años de edad, es considerada una curandera por los pobladores. Su madre, Doña Fresia, la ha controlado durante años y se encarga de que sólo se dedique a sus labores de “santidad”. Un día, sin embargo, al conocer a un joven agricultor, Clara comenzará a experimentar un despertar sexual y místico que podría ayudarla curarse a sí misma. Con toques de realismo mágico y una propuesta narrativa donde tanto la corporeidad de la protagonista como la naturaleza de su entorno conforman el centro gravitacional, la ópera prima de la joven directora Nathalie Álvarez Mesén es una poética inmersión al universo de la sexualidad femenina.", duracionTiempo: 106.0),
    Pelicula(titulo: "Cenote", genero: "Documental | Naturaleza", image: UIImage(named: "cenote")!,desc: "En el norte de Yucatán, los pozos naturales llamados cenotes constituían la única fuente de agua para los mayas. Algunos se usaban para sacrificios rituales y los mayas creían que estas fuentes sagradas conectaban al mundo con la vida después de la muerte. La cineasta japonesa Kaori Oda realizó varios viajes a Yucatán para filmar las profundidades turquesas de los pozos y conocer a los locales. El resultado es una meditación poética y una experiencia sensorial sobre el papel mítico de estos cuerpos de agua en la vida maya.", duracionTiempo: 75.0),
    Pelicula(titulo: "Volveré", genero: "Ficción", image: UIImage(named: "volvere")!, desc:  "En un país con miles de desaparecidos, Alejandra, una mujer frívola, divorciada y madre de dos hijos, se enfrenta a la desaparición de su hermano Salvador, quien documenta la depredación ecológica de una minera canadiense. La vida se vuelve más difícil con pérdidas laborales y familiares. Alejandra luchará por proteger a su familia y aprenderá que el amor lo enfrenta todo.", duracionTiempo: 102.0)
]

